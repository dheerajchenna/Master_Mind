﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MasterMind
{
    class Program
    {
        static void Main(string[] args)
        {
            int[] randomNumbers = new int[4];
            char[] results = new char[4];
            Random r = new Random();
            bool wonFlag = false;

            int idx = 0, ctr = 0;
            while(idx < 4) {
                var randNum = r.Next(7);
                if(randomNumbers.Any(p=>p == randNum))
                {
                    continue;
                }
                randomNumbers[idx++] = randNum;

                //Console.Write(randNum);
            }
            //Console.WriteLine(" ");


            while (ctr < 10 && !wonFlag)
            {
                Console.Write("Please guess the number ({0}): ", ctr+1);
                var inputValue = Console.ReadLine();
                if(inputValue.Length != 4)
                {
                    Console.WriteLine("Please enter number having 4 digits");
                    continue;
                }
                var inputCharArray = inputValue.ToCharArray();
                foreach (var ch in inputCharArray)
                {
                    if (ch < 49 || ch > 54)
                    {
                        Console.WriteLine("Please enter number having 4 digits");
                        continue;
                    }
                }

                wonFlag = true;
                for(idx = 0; idx < 4; idx++)
                {
                    if(randomNumbers[idx]+48 == inputCharArray[idx])
                    {
                        results[idx] = '+';
                    }
                    else if(inputCharArray.Any(p=>(p-48) == randomNumbers[idx]))
                    {
                        results[idx] = '-';
                        wonFlag = false;
                    }
                    else
                    {
                        results[idx] = ' ';
                        wonFlag = false;
                    }
                    Console.Write(inputCharArray[idx]);
                }
                Console.WriteLine(' ');
                for (idx = 0; idx < 4; idx++)
                {
                    Console.Write(results[idx]);
                }
                Console.WriteLine(' ');
                ctr++;
            }

            Console.WriteLine(wonFlag ? "Wooow!!! You are a mastermind. " : "You have lost the game. Better luck next time. ");
            Console.ReadLine();
        }
    }
}
